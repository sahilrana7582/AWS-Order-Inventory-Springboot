package com.order_tracking.user_servicew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserServicewApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServicewApplication.class, args);
	}

}
