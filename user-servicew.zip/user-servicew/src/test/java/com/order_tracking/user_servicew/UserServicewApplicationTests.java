package com.order_tracking.user_servicew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServicewApplicationTests {

	@Test
	void contextLoads() {
	}

}
